#include<iostream>
using namespace std;
string encodeCRC(string bitstream,int segsize);