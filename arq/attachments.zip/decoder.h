#include<iostream>
#include "protocol.h"
using namespace std;
bool decodeCRC(string bitstream,int segSize);